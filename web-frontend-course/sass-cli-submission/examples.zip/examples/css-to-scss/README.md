# CSS to SCSS refactor

This example starts with the CSS shown in the CodeGym exercise and reorganizes it into `abstracts`, `base`, `layout`, and `components`. The SCSS uses shared variables, mixins, and nested component states.

From the project root, run `npm run sass:refactor` to compile `main.scss` into `css/main.css`. Open `index.html` to view the result.
