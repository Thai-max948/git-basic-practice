# Portfolio refactored with Sass

This keeps the existing portfolio pages and responsive layout while moving the design tokens into Sass variables and focus styling into a reusable mixin. The primary button uses a nested hover state. The original CSS is kept in `legacy/style.css` for comparison.

From the project root, run `npm run sass:portfolio`. The generated stylesheet is `examples/portfolio-sass-refactor/css/main.css`.
