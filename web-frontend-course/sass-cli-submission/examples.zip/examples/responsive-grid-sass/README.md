# Responsive Grid rebuilt with Sass

This exercise refactors the CodeGym `responsive-grid` starter into a small 12-column layout. The original starter is preserved in `source/responsive_grid.htm`; the rebuilt page uses Sass variables, mixins, loops, nesting, and responsive breakpoints.

From the project root, run:

```bash
npm run sass:grid
```

Open `examples/responsive-grid-sass/index.html` to view the result.
